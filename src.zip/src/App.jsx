import './App.css'
import Chatbot from './chatbot'

function App() {
  return (
    <div>
      <h1>Test App</h1>
      <Chatbot />
    </div>
  )
}

export default App